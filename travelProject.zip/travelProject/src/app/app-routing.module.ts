import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { TenantloginComponent } from './tenantlogin/tenantlogin.component';
import { TenantregisterComponent } from './tenantregister/tenantregister.component';

const routes: Routes = [{path : 'loginTraveller' , component : LoginComponent},
                          {path : 'loginTenant' , component : TenantloginComponent} ,
                          {path : 'registerTraveller' , component : RegisterComponent} ,
                          {path : 'registerTenant' , component : TenantregisterComponent} , 
                          {path : 'home' , component : HomeComponent}
                        ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
