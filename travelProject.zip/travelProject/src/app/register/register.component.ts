import { Component, OnInit } from '@angular/core';
import { TravellerService } from '../traveller.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  traveller: any;
  constructor(private router : Router ,private service: TravellerService) {
    this.traveller = {travellerId: '', travellerName: '',travellerDOB:' ',travellerGender:' '
    ,travellerGmailId:' ', travellerCity: '', travellerState: '',travellerCountry:'' ,travellerPassword: '', 
    travellerPhoneNo: '',travellerAadharNo:''
    };
 
  }
  ngOnInit(): void {
    console.log("hkjk")
  }

  register(): void {
    this.service.registertraveller(this.traveller).subscribe((result: any) => { console.log(result); } );
    console.log(this.traveller);
    this.router.navigate(['loginTraveller']);
  }


}
