import { Component, OnInit } from '@angular/core';
import { TravellerService } from '../traveller.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginform: any;
  retrivedData : any;
  constructor(private router : Router ,private service : TravellerService) {
    this.loginform = {emailId : '', password : ''};
   }

  ngOnInit(): void {
  }
  getTravellerByUserPass() {
    this.service.getTravellerByUserPass(this.loginform).subscribe((result: any) => {console.log(result); this.retrivedData = result;
    if(this.retrivedData === null){
      alert("Wrong Credentials");

    }
    else{
      alert("logged in");
      this.router.navigate(['home']);
      
      localStorage.setItem("TravellerDetails", this.retrivedData.travellerName);
    }
    });
    }
}
