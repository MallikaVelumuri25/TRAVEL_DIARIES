import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TenantService {
  //httpClient: any;
  constructor(private httpClient: HttpClient) {
    //this.isUserLogged = false;
  }
  getTenantByUserPass(loginform: any) {
    //throw new Error('Method not implemented.');
    console.log(loginform);
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getTenantByUserPass/'+ loginform.emailId + '/' + loginform.password);
   }
  registertenant(tenant: any) {
    console.log("dsjff")
    console.log(tenant)
    return this.httpClient.post('RESTAPI_TRAVELDIARIES/webapi/myresource/registertenant/',  tenant);
   }

  
}
