import { Component, OnInit } from '@angular/core';
import { TenantService } from '../tenant.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tenantregister',
  templateUrl: './tenantregister.component.html',
  styleUrls: ['./tenantregister.component.css']
})
export class TenantregisterComponent implements OnInit {

  tenant: any;
  constructor(private router : Router ,private service: TenantService) {
    this.tenant = {tenantId: '', tenantName: '',tenantPhoneNo:' ',tenantMailId:' '
    ,tenantCity:' ', tenantState: '', tenantCountry: '',tenantPassword:''};
  }
  
  ngOnInit(): void {
  }
  register(): void {
    this.service.registertenant(this.tenant).subscribe((result: any) => { console.log(result); } );
    console.log(this.tenant);
    this.router.navigate(['loginTenant']);
  }



}
