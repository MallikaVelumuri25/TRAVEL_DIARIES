import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TenantregisterComponent } from './tenantregister.component';

describe('TenantregisterComponent', () => {
  let component: TenantregisterComponent;
  let fixture: ComponentFixture<TenantregisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TenantregisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TenantregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
