import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TenantService } from '../tenant.service';

@Component({
  selector: 'app-tenantlogin',
  templateUrl: './tenantlogin.component.html',
  styleUrls: ['./tenantlogin.component.css']
})
export class TenantloginComponent implements OnInit {
  loginform: any;
  retrivedData: any;

  constructor(private router : Router ,private service : TenantService) {
    this.loginform = {emailId : '', password : ''};
   }

  ngOnInit(): void {
  }
  getTenantByUserPass() {
    this.service.getTenantByUserPass(this.loginform).subscribe((result: any) => {console.log(result); this.retrivedData = result;
    if(this.retrivedData === null){
      alert("Wrong Credentials");

    }
    else{
      alert("logged in");
      this.router.navigate(['home']);
    }
    });
    }
}
