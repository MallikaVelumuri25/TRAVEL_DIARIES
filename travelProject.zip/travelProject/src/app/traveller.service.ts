import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class TravellerService {
  getTravellerByUserPass(loginform: any) {
    //throw new Error('Method not implemented.');
    console.log(loginform);
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getTravellerByUserPass/'+ loginform.emailId + '/' + loginform.password);
   }
  
  //private isUserLogged: any;
  constructor(private httpClient: HttpClient) {
    //this.isUserLogged = false;
  }
  registertraveller(traveller: any) {
    console.log("dsjff")
    console.log(traveller)
    return this.httpClient.post('RESTAPI_TRAVELDIARIES/webapi/myresource/registertraveller/',  traveller);
   }

}
